package CyberCar;

public enum CRUDMode {
	
	ADD, 
	UPDATE, 
	DELETE, 
	QUIT, 
	LISTALLSTUDENTS,
	INVALID

}
