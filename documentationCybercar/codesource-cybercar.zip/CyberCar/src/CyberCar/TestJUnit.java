package CyberCar;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;
import CyberCar.ConnectionFactory;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.jupiter.api.Test;

class TestJUnit {

	@Test
	void test() throws SQLException 
	{
		
		
		Pattern pattern = Pattern.compile("^\\d{10}$");
		Matcher matcher = pattern.matcher("0639101120");
		
		
		/**
		 * teste le fonctionnemnt du controle de saisie de numero de telephone.
		 */
		assertTrue(matcher.matches());
		
		/**
		 * verification si il y a une connexion avec la base.
		 */
		assertNotNull(ConnectionFactory.getConnection()); 
		
		//assertNotNull(GestionRH.affichageEmploye());
		
		
	}

}
